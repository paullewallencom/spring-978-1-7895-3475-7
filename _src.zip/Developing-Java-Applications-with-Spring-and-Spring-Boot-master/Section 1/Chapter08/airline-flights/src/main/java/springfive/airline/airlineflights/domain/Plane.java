package springfive.airline.airlineflights.domain;

import lombok.Data;

@Data
public class Plane {

  String id;

  PlaneModel model;

}
