package springfive.airline.airlineplanes.domain;

import lombok.Data;

@Data
public class Class {

  String id;

  String name;

}
