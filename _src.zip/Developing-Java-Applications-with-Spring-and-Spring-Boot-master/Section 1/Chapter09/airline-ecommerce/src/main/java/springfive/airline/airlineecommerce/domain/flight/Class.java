package springfive.airline.airlineecommerce.domain.flight;

import lombok.Data;

@Data
public class Class {

  String id;

}
