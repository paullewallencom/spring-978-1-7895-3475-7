package springfive.airline.airlineecommerce.domain.passenger;

import lombok.Data;

@Data
public class PassengerDocument {

  String name;

  String value;

}
