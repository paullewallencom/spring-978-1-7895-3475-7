package springfive.airline.airlinebooking.domain.payment;

public enum  PaymentStatus {

  DECLINED,

  APPROVED,

}
