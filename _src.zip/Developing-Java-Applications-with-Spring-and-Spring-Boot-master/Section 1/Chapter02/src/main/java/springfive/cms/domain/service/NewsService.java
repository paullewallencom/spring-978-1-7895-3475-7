package springfive.cms.domain.service;

/**
 * @author claudioed on 29/10/17. Project cms
 */
public class NewsService {

}
