package springfive.cms.domain.repository;

import org.springframework.stereotype.Service;
import springfive.cms.domain.models.Category;

/**
 * @author claudioed on 29/10/17. Project cms
 */
@Service
public class CategoryRepository extends AbstractRepository<Category> {
}
