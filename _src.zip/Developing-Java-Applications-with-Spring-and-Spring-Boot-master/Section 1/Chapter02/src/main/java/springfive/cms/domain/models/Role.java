package springfive.cms.domain.models;

/**
 * @author claudioed on 28/10/17. Project cms
 */
public enum Role {

  AUTHOR,

  REVIEWER

}
